#Life in weeks 
print("welcome to the life in weeks & years identifier")
age = input("whats ur current age?\n")
age_as_int = int(age)
years = 90 - age_as_int
weeks = years * 52
print(f"You have {years} years and {weeks} weeks left")